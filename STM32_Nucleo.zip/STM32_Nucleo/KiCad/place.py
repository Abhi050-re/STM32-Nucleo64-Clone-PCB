import pcbnew
board = pcbnew.GetBoard()

def place(ref, x, y, rot=0, flip=False):
    fp = board.FindFootprintByReference(ref)
    if fp:
        fp.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x), pcbnew.FromMM(y)))
        fp.SetOrientationDegrees(rot)
        if flip:
            fp.Flip(fp.GetPosition(), True)

# ── TOP ROW: LDO | USB | ST-LINK all on same Y ───────────
place("U3",  85,  65, 0)
place("J1",  105, 62, 0)
place("F1",  97,  62, 0)
place("D1",  93,  62, 0)
place("U2",  135, 65, 0)
place("R10", 135, 57, 0)

# LDO caps - tight column right of U3
place("C1",  92,  60, 0)
place("C2",  92,  65, 0)
place("C3",  92,  70, 0)
place("C4",  92,  75, 0)

# Ferrite + VDDA caps below U3
place("FB1", 85,  75, 0)
place("C5",  85,  80, 0)
place("C6",  85,  85, 0)
place("R1",  85,  90, 0)

# ST-LINK caps - tight column left of U2
place("C21", 125, 60, 0)
place("C22", 125, 65, 0)
place("C23", 125, 70, 0)
place("C24", 125, 75, 0)
place("C25", 125, 80, 0)

# SWD header right of U2
place("CN4", 145, 65, 0)

# ── CENTER: MAIN MCU ──────────────────────────────────────
place("U1", 105, 100, 0)

# Left caps column - 5mm spacing
place("C12", 92, 88, 0)
place("C13", 92, 93, 0)
place("C14", 92, 98, 0)
place("C15", 92, 103, 0)
place("C20", 92, 108, 0)

# Right caps column - 5mm spacing
place("C7",  118, 88, 0)
place("C8",  118, 93, 0)
place("C9",  118, 98, 0)
place("C10", 118, 103, 0)
place("C11", 118, 108, 0)

# Crystal caps column
place("C16", 125, 88, 0)
place("C17", 125, 93, 0)
place("C18", 125, 98, 0)
place("C19", 125, 103, 0)

# Crystals
place("X1", 130, 90, 0)
place("X2", 130, 98, 0)

# Crystal resistors
place("R3", 130, 85, 0)
place("R4", 130, 104, 0)

# ── BELOW MCU ─────────────────────────────────────────────
place("R2",  92,  112, 0)
place("R9",  92,  117, 0)
place("R5",  118, 112, 0)
place("R6",  118, 117, 0)
place("R7",  118, 122, 0)
place("R8",  105, 112, 0)
place("LD2", 105, 117, 0)
place("SW1", 98,  123, 0)
place("SW2", 105, 123, 0)

# ── MORPHO - same Y center as U1 ─────────────────────────
place("CN7",  72,  100, 0)
place("CN10", 138, 100, 0)

# ── ARDUINO BOTTOM - evenly spaced same Y ─────────────────
place("CN5",  80,  138, 0)
place("CN6",  91,  138, 0)
place("CN8",  105, 138, 0)
place("CN9",  119, 138, 0)

pcbnew.Refresh()
print("Placement complete")